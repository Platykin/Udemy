#pragma once

/**
 * @brief Prints out hello world to the console
 *
 */
void print_hello_world();
