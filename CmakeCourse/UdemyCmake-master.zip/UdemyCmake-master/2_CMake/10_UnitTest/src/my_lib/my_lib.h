#pragma once

void print_hello_world();

std::uint32_t factorial(std::uint32_t number);
