#pragma once

void Function();
