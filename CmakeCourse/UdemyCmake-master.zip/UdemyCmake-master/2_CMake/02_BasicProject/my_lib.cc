#include <iostream>

#include "my_lib.h"

void print_hello_world()
{
    std::cout << "Hello World!\n";
}
